document.addEventListener("DOMContentLoaded", function () {
    // Mobile navigation
    const menuButton = document.querySelector(".menu-toggle");
    const navigation = document.querySelector(".main-nav");

    if (menuButton && navigation) {
        menuButton.addEventListener("click", function () {
            const isOpen = navigation.classList.toggle("show");
            menuButton.setAttribute("aria-expanded", String(isOpen));
        });

        navigation.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                navigation.classList.remove("show");
                menuButton.setAttribute("aria-expanded", "false");
            });
        });
    }

    // Back-to-top button
    let topButton = document.querySelector(".back-to-top");

    if (!topButton) {
        topButton = document.createElement("button");
        topButton.type = "button";
        topButton.className = "back-to-top";
        topButton.textContent = "↑";
        topButton.setAttribute("aria-label", "Back to top");
        document.body.appendChild(topButton);
    }

    window.addEventListener("scroll", function () {
        topButton.classList.toggle("show", window.scrollY > 300);
    });

    topButton.addEventListener("click", function () {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    // Basic form validation and confirmation
    document.querySelectorAll("form").forEach(function (form) {
        form.addEventListener("submit", function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                form.reportValidity();
                return;
            }

            // Prevent a false claim that a message was sent to a server.
            event.preventDefault();

            let message = form.querySelector(".form-message");

            if (!message) {
                message = document.createElement("p");
                message.className = "form-message";
                message.setAttribute("role", "status");
                form.appendChild(message);
            }

            message.textContent =
                "Your form has been validated. A live submission service still needs to be connected to send your message.";
            message.classList.add("success");
        });
    });
});